starttime=`date`
totaltrajnumber=$(wc -l alltrajforprediction | awk '{print $1}')
workingfolder=`pwd`
targetfolder=$workingfolder/bintrajpred

for (( i = 1; i <= $totaltrajnumber; i++ )); do
    sed -n "$i"p alltrajforprediction  > tmpCurrenttraj
    geoRecordpath=$(awk '{print $1}' tmpCurrenttraj)
    originalfolderName=$(awk -F'/' '{print $5}' tmpCurrenttraj)
    isomernumber=$(awk '{print $8}' tmpCurrenttraj)
    awk "/^$isomernumber/,/^Gaussian zpe/" $geoRecordpath > tmpCurrenttraj_geoRecord
    Totalatom=$(sed -n 2p tmpCurrenttraj_geoRecord)
    sed -n 3,24p tmpCurrenttraj_geoRecord | awk '{print $1,$2,$3,$4}' > $targetfolder/input_XYZgeom
    sed -n 3,24p tmpCurrenttraj_geoRecord | awk '{print $5}' > $targetfolder/atomicmasslist
    sed -n 25,46p tmpCurrenttraj_geoRecord > $targetfolder/input_velocity   
    python 3_KRR_ML_Predicting_Verlet.py 
    newfolder="$targetfolder"/"$originalfolderName"_traj"$isomernumber"
    mkdir $newfolder
    cp $targetfolder/{input*,tmp*,*log,atom*} $newfolder
done
endtime=`date`

echo This job began at $starttime and ended at $endtime > $targetfolder/jobtime.log

