# prepare new run
currentfolder=`pwd`
workingfolder=$currentfolder/bintrajpred
proggramdir=/work/kykuan/KRR_Progdyn/binall100

echo 22 >> $workingfolder/geomxyz.traj
echo "" >> $workingfolder/geomxyz.traj
cat bintrajpred/tmp_geomxyz >> $workingfolder/geomxyz.traj
(echo  -e '$molecule \n0 1'  && cat bintrajpred/tmp_geomxyz && echo  '$end')  > $workingfolder/tmp_QCHEMgeom
python3 $proggramdir/subroutine_Feature_Generation2.py
sed ':a;N;$!ba;s/\n/ /g' bintrajpred/tmp_CMgeom | cut -d "[" -f 2 | cut -d "]" -f 1 > $workingfolder/tmp_currentCM



