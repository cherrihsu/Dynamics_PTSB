currentpath=`pwd`
trajpredFolder=""$currentpath"/bintrajpred"


echo "Removing previous result"
rm -f $trajpredFolder/*log $trajpredFolder/tmp* $trajpredFolder/atom* $trajpredFolder/*.traj

echo "copying first geom to nextgeom"
cp $trajpredFolder/input_XYZgeom $trajpredFolder/tmp_geomxyz


