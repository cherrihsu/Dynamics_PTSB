import numpy as np
from sklearn.metrics.pairwise import pairwise_kernels
import sys,time,os
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import r2_score
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error

def main():    
    
    ####### TrajTrajTrajTrajTrajTrajTrajTrajTrajTrajTrajTrajTrajTrajTrajTrajTrajTrajTrajTrajTrajTrajTrajTraj ######
    total_sample = 1   # Number of molecule run in parallel
    trajMaxlength = 500 
    TotalAtoms = 22
    timestep = 1 # Unit: femtosecond (1e-15 sec)
    RgasK = 1.98588e-3
    temperature = 298.15
    # Damping
    damping = 1
    dampingfactor = 0.993  

    currentfolder = os.getcwd()
    outputfolder = currentfolder + '/bintrajpred/'
    os.system("bash KRRtrajpred_initialization.sh") # Clear Previous run and copy the next run into tmp files
    inputgeom_file = outputfolder + 'tmp_geomxyz'

    # Original data statistics
    KRR_crudedatapath = "/datasets/" # directory for the KRR models. 
    dataset1_file = KRR_crudedatapath + 'A_CoulombMatrix'
    dataset2_file = KRR_crudedatapath + 'A_Boltz298K_CM_TS2toPD_25k'
    dataset3_file = KRR_crudedatapath + 'A_Boltz298K_CM_TS2toPD2_25k'

    feature1 = np.loadtxt(dataset1_file, usecols=(np.arange(0,253)))
    feature2 = np.loadtxt(dataset2_file, usecols=(np.arange(1,254)))
    feature3 = np.loadtxt(dataset3_file, usecols=(np.arange(1,254)))

    # Calculate mean and standard deviation to determine which KRR model to use.
    mean1 = np.mean(feature1, axis=0); mean1 = np.reshape(mean1, (1, mean1.shape[0]))
    std1 = np.std(feature1, axis=0); std1 = np.reshape(std1, (1, std1.shape[0]))
    mean2 = np.mean(feature2, axis=0); mean2 = np.reshape(mean2, (1, mean2.shape[0]))
    std2 =  np.std(feature2, axis=0); std2 = np.reshape(std2, (1, std2.shape[0]))
    mean3 = np.mean(feature3, axis=0); mean3 = np.reshape(mean3, (1, mean3.shape[0]))
    std3 =  np.std(feature3, axis=0); std3 = np.reshape(std3, (1, std3.shape[0]))

    #### KRR parameters and paths for pre-trained KRR models
    KRR_modelpath = 'KRR_traj_multimodels/'
    # KRR model PE 1 (Sampled from SM to TS2)
    params_PE1 = {"metric":'rbf', "gamma": 5e-4}
    weight_coef_PE1 = np.loadtxt(KRR_modelpath + 'Weight_List_PE_isotope.txt')
    trained_feature_PE1 = np.loadtxt(KRR_modelpath + 'Train_Feature_PE_isotope.txt')
    # KRR model PE 2 (Sampled from PD to PD2 via TS2)
    params_PE2 = {"metric":'rbf', "gamma": 1e-4}
    weight_coef_PE2 = np.loadtxt(KRR_modelpath + 'Weight_List_PE_TS2toPD2_25k.txt')
    trained_feature_PE2 = np.loadtxt(KRR_modelpath + 'Train_Feature_PE_TS2toPD2_25k.txt')
    # KRR model PE 2 (Sampled from PD to PD2 via TS2)
    params_PE2 = {"metric":'rbf', "gamma": 1e-4}
    weight_coef_PE2 = np.loadtxt(KRR_modelpath + 'Weight_List_PE_TS2toPD2_25k.txt')
    trained_feature_PE2 = np.loadtxt(KRR_modelpath + 'Train_Feature_PE_TS2toPD2_25k.txt')

    # KRR model force 1 (Sampled from SM to TS2)
    params_Force1 = {"metric":'rbf', "gamma": 0.001}
    weight_coef_Force1 = np.loadtxt(KRR_modelpath + 'Weight_List_isotope.txt')
    trained_feature_Force1 = np.loadtxt(KRR_modelpath + 'Train_Feature_isotope.txt')
    # KRR model force 2 (Sampled from TS2 to PD)
    params_Force2 = {"metric":'rbf', "gamma": 0.001}
    weight_coef_Force2 = np.loadtxt(KRR_modelpath + 'Weight_List_Force_TS2toPD_25k.txt')
    trained_feature_Force2 = np.loadtxt(KRR_modelpath + 'Train_Feature_Force_TS2toPD_25k.txt')    
    # KRR model force 3 (Sampled from TS2 to PD2)
    params_Force3 = {"metric":'rbf', "gamma": 0.001}
    weight_coef_Force3 = np.loadtxt(KRR_modelpath + 'Weight_List_Force_TS2toPD2_25k.txt')
    trained_feature_Force3 = np.loadtxt(KRR_modelpath + 'Train_Feature_Force_TS2toPD2_25k.txt')


    status = ' '
    Xfilename = outputfolder + 'tmp_currentCM'
    iteration_number = 0
    discriminant = 1


    for i in range(trajMaxlength):
        iteration_number += 1
        os.system("bash KRRtrajpred_propagation.sh")
        X = pd.read_csv(Xfilename, sep='\s+',header=None)
        # KRR parameters and paths for pre-trained KRR models
        params = {"metric":'rbf', "gamma": 1e-3}
        Xfilename = outputfolder + 'tmp_currentCM'
    
        ###### Compile data #####
        if not os.path.exists(Xfilename):
            raise ValueError('%s does not exist!' % Xfilename)
        #if not os.path.exists(Yfilename):
        #  raise ValueError('%s does not exist!' % Yfilename)
        X = pd.read_csv(Xfilename, sep='\s+',header=None)
        #Y = pd.read_csv(Yfilename, sep='\s+',header=None)
    
        X = X.loc[:(total_sample-1)]
        #Y = Y.loc[:(total_sample-1)] # Check the label file and exculde the header column
        #Y = Y.loc[:(total_sample-1), 1] # Check the label file and exculde the header column
        #Y = pd.DataFrame(Y)
    
        X = np.array(X)
        #Y = np.array(Y) #.flatten()
        print("X shape: ", X.shape)
    
        ###  Calculate the Z-value to each data set and use the shortest one ###
        
        Z1 = np.mean(np.divide(np.abs(np.subtract(X, mean1)), std1, out=np.zeros_like(X), where=std1!=0))
        Z2 = np.mean(np.divide(np.abs(np.subtract(X, mean2)), std2, out=np.zeros_like(X), where=std2!=0))
        Z3 = np.mean(np.divide(np.abs(np.subtract(X, mean3)), std3, out=np.zeros_like(X), where=std3!=0))
    
        Z_min = np.min([Z1, Z2, Z3])
    
        print("Z1", Z1)
        print("Z2", Z2)
        print("Z3", Z3)
        print("Z_min", Z_min)
    
        if ( Z_min == Z1 ):
            print("Using dataset 1 to predict force")
            model="model1"
            cal_kernel_PE = pairwise_kernels(X, trained_feature_PE1, **params_PE1)
            Y_pred_PE = cal_kernel_PE.dot(weight_coef_PE1)
            cal_kernel_Force = pairwise_kernels(X, trained_feature_Force1, **params_Force1)
            Y_pred_Force = cal_kernel_Force.dot(weight_coef_Force1)
        elif ( Z_min == Z2 ):
            model="model2"
            print("Using dataset 2 to predict force")
            cal_kernel_PE = pairwise_kernels(X, trained_feature_PE2, **params_PE2)
            Y_pred_PE = cal_kernel_PE.dot(weight_coef_PE2)
            cal_kernel_Force = pairwise_kernels(X, trained_feature_Force2, **params_Force2)
            Y_pred_Force = cal_kernel_Force.dot(weight_coef_Force2)
        elif ( Z_min == Z3 ):
            model="model3"
            print("Using dataset 3 to predict force")
            cal_kernel_PE = pairwise_kernels(X, trained_feature_PE3, **params_PE3)
            Y_pred_PE = cal_kernel_PE.dot(weight_coef_PE3)
            cal_kernel_Force = pairwise_kernels(X, trained_feature_Force3, **params_Force3)
            Y_pred_Force = cal_kernel_Force.dot(weight_coef_Force3)
    
        else:
            print("Error in finding closest datasets") 
    
        initialgeom = np.loadtxt(inputgeom_file, usecols=(1,2,3))
        initialgeom = np.reshape(initialgeom, (TotalAtoms, 3))
    
        # Get cirtical internal coordinate data
        C28 = np.linalg.norm(initialgeom[1][:] - initialgeom[7][:]) # TS1
        C110 = np.linalg.norm(initialgeom[0][:] - initialgeom[9][:]) # TS2 --> PD
        C412 = np.linalg.norm(initialgeom[3][:] - initialgeom[11][:]) # TS2 --> PD2
    
        """
        if ( C28 < 1.8 ): # Switch to model 2 when cross TS2
        print("Using model 2")
        cal_kernel = pairwise_kernels(X, trained_feature_Force2, **params_Force2)
        Y_pred = cal_kernel.dot(weight_coef_Force2)
        model = "model2"
        else: # Remain as model 1 around TS1
        print("Using model 1")
        cal_kernel = pairwise_kernels(X, trained_feature_Force1, **params_Force1)
        Y_pred = cal_kernel.dot(weight_coef_Force1)
        model = "model1"
        """
        Y_pred_PE = Y_pred_PE[0]
        print("KRR predicted potential energy: ", Y_pred_PE, " kcal/mol")
        Y_pred_Force = Y_pred_Force * 0.496147348807677 # convert unit from Eh/bohr to amu*angstrom/(fs)^2
        Y_pred_Force = Y_pred_Force.tolist()                
        Y_pred_Force = np.reshape(Y_pred_Force, (TotalAtoms, 3))
        print("KRR predicted force: ", Y_pred_Force)
    
        atomtype = np.loadtxt(inputgeom_file, usecols=(0), dtype=str)
        atomtype = np.reshape(atomtype, (TotalAtoms, 1))
        print("---------atomtype----------")
        print(atomtype)
        print("---------------------------")
       # atomtype = np.reshape(atomtype (TotalAtoms, 1))
        atomicmass = []
        for j in range(len(atomtype)):
            if atomtype[j] == 'C':
                atomicmass.append(12.0000)
            elif atomtype[j] == 'H':
                atomicmass.append(1.00784)
            else:
                print("Atomic mass ERROR!")
        atomicmass = np.reshape(atomicmass, (TotalAtoms, 1))
    
        ##################################################################          
        #atomicmass[0,0] = 20.0 # Set isotopes                           #
        ##################################################################
    
        print("---------atomicmass----------")
        print(atomicmass)
        print("-----------------------------")
        print("---------initial geometry----------")
        print(initialgeom)
        print("-----------------------------------")
    
        # Define initial velocity
        # initial_vel = np.zeros((TotalAtoms,3))
        initial_vel = np.loadtxt(outputfolder + "input_velocity")
        initial_vel = np.reshape(initial_vel, (TotalAtoms, 3))
    
        print("---------initial velocity----------")
        print(initial_vel)
        print("-----------------------------------")
    
        # Calculate Acceleration
        acceleration = np.divide(Y_pred_Force, atomicmass)
        print("---------acceleration----------")
        print(acceleration)
        print("-------------------------------")
    
        if "oldergeom" in locals():
            print("Use Basic Störmer–Verlet algorithm (without velocity)")
            finalgeom = initialgeom + damping*(initialgeom - oldergeom) + acceleration*timestep*timestep
            velocity = (finalgeom - oldergeom)/(2*timestep)
        else:
            print("Use Velocity Verlet")
            velocity = initial_vel
            finalgeom = initialgeom + velocity*timestep + 0.5*acceleration*timestep*timestep
    
        oldergeom = initialgeom  # Save initialgeom as the x_n-1 for the next point
        #finalgeom = atomtype + finalgeom
        finalgeom = np.concatenate((atomtype,finalgeom), axis=1)
        print("---------New Velocity----------")
        print(velocity)
        print("-------------------------------")
        print("---------Final Geomitry----------")
        print(finalgeom)
        print("-------------------------------")
        np.savetxt(outputfolder + "tmp_geomxyz", finalgeom, delimiter=" ", fmt="%s")        
    
        #### Report dynamic data ####
        # Momentum
        momentum = atomicmass*velocity
        np.savetxt(outputfolder + "tmp_momentum", momentum)
        print("---------Momentum----------")
        print(finalgeom)
        print("---------------------------")        
        with open(outputfolder + "momentum.log", "a") as f:
            f.write(str(momentum))
            f.write("\n")
            f.write("\n")
       
        # Kinetic energy
        kinetic_energy = momentum*momentum / (2*atomicmass)
        np.savetxt(outputfolder + "tmp_KE", kinetic_energy)
        KE_sum = np.sum(kinetic_energy, axis=1)
        KE_sum = KE_sum*2390 # Convert to kcal/mol
        np.savetxt(outputfolder + "tmp_KE_sum", KE_sum)
        with open(outputfolder + "KE_sum.log", "a") as f:
            f.write(str(KE_sum))
            f.write("\n")
            f.write("\n")
        print("---------Kinetic energy----------")
        print(KE_sum)
        print("---------------------------------")
        total_KE = sum(KE_sum)
        
        if i == 0:
            energy_total_initial = total_KE + Y_pred_PE
            energy_total = energy_total_initial
        else:
            energy_total = total_KE + Y_pred_PE    

        # calculate apparent temperature
        apparentTemp = 2*total_KE/(3*TotalAtoms*RgasK) # Unit of kinetic energy is kcal/mol
        if apparentTemp > temperature:
            damping = dampingfactor
            #print("AppTemp", apparentTemp, "damping", damping)
        elif apparentTemp < temperature:
            damping = 1/dampingfactor
            #print("AppTemp", apparentTemp, "damping", damping)
        else:
            damping = 1
            #print("AppTemp", apparentTemp, "damping", damping)
   
        with open(currentfolder + '/traj_summary', "a") as f:
           f.write("point: ")
           f.write(str(i))
           f.write(" C2-C8: ")
           f.write(str(C28))
           f.write(" C1-C10: ")
           f.write(str(C110))
           f.write(" C4-C12: ")
           f.write(str(C412))
           f.write(" Z1: ")
           f.write(str(Z1))
           f.write(" Z2: ")
           f.write(str(Z2))
           f.write(" Z3: ")
           f.write(str(Z3))
           f.write(" ")
           f.write(model)
           f.write(" E_KRRpot: ")
           f.write(str(Y_pred_PE))
           f.write(" E_KRRkin: ")
           f.write(str(total_KE))
           f.write(" E_tot: ")
           f.write(str(energy_total))
           f.write(" ")
           f.write(" AppTemp: ")
           f.write(str(apparentTemp))
           f.write(" ")
           f.write(" damping: ")
           f.write(str(damping))
           f.write(" ")
           f.write("\n")
           # Set termination criteria
           if C110 < 1.7:
                status = "Product 1 Formed. XXXXP1"
                f.write(status)
                f.write("\n")
                break
           elif C412 < 1.7:
                status = "Product 2 Formed. XXXXP2"
                f.write(status)
                f.write("\n")
                break
           elif energy_total > 10*energy_total_initial:
                status = "Exploaded. XXXXH"
                f.write(status)
                f.write("\n")
                break
           elif ((C110 > 6) or (C412 > 6)):
                status = "Recrossed. XXXXS"
                f.write(status)
                f.write("\n")
                break
           elif i == trajMaxlength - 1:
                status = "Maximum point reached. XXXXI" 
                f.write(status)
                f.write("\n")
           else:
                continue 
              

        #model.eval()
        #predict = model.forward(X_test).detach()
        #MAE = (predict - Y_test).abs().mean()
        #print(predict, Y_test)
        #print(MAE)
    
        ###### Write Output File #####
        #predict.cpu()
        #np.savetxt(output_filename, Y_pred)
    
    
        #Output_file = open(output_filename, 'w')
        #Output_file.write('%s\n' %(predict))
        #print(predict[:, 0])   
    
        """
        # Make scatter plot of each axis of force
        column_num = 10 # How many plot in a row?
        output_dim = Y_pred.shape[1]
        plot_column = output_dim // column_num
        plot_rest = output_dim % column_num
        add_col = 0
    
        #plt.figure()
        if plot_rest > 0:
            add_col = 1
        else:
            add_col = 0
        plot_column = plot_column + add_col
    
        plt.rc('xtick', labelsize=4)
        plt.rc('ytick', labelsize=4)
        fig, axs = plt.subplots(plot_column, column_num, clear=True)
    
        for i in range(plot_column):
            for j in range(column_num):
                if column_num*i+j < output_dim:
                    axs[i, j].scatter(Y_exp[:, column_num*i+j], Y_pred[:, column_num*i+j], s=1, alpha=0.1)
                else:
                    break
        plt.show()
    
        #plt.title('Training Performance on Each Coordinate')
        #plt.savefig("Dipimethane_ScatterMatrix_Force_Test.png", dpi=figure_dpi,format="png")
        """
        """
        plt.rc('xtick', labelsize=12)
        plt.rc('ytick', labelsize=12)
        #plt.figure()
    
        Y_exp = Y_exp.flatten()
        Y_pred = Y_pred.flatten()
    
    
        Title = 'Predicted Performance on New Set'
        plt.title(Title)
        plt.xlabel('Expect relative energy (Eh/Bohr)')
        plt.ylabel('Predicted relative energy (Eh/Bohr)')
        plt.scatter(Y_exp,Y_pred,alpha=1)
        m, b = np.polyfit(Y_exp, Y_pred, 1)
        plt.plot(Y_exp, m*Y_exp+b, 'r-')
        r2 = r2_score(Y_exp, Y_pred)
        MAE = mean_absolute_error(Y_exp, Y_pred)*627.509/0.529
        RMSE = np.power(mean_squared_error(Y_exp, Y_pred), 0.5)*627.509/0.529
        plt.text(-0.12, 0.05, "$R^2$: %2.5f\nMAE (kcal/molA): %2.3f\nRMSE (kcal/molA): %2.3f" %(r2, MAE, RMSE), fontsize=12)
    
        plt.show()
        """
     
    
        """   
        Output_file = open(output_filename, 'w')
        #Output_file.write('Model infomation: %s\n' %(output_filename))
        #short = np.linspace(0., 354., 60)
        #long = np.linspace(0., 354., 60)
        for i in range(3600):
           Output_file.write('%s\n' %(predict[i, 0]))
        """   

if __name__ == '__main__':
    main()



"""

# Assign your input file
filename="Eth_000002.inp"



# Read Q-Chem input file: Cartesian coordninates and atom type of an ethylene pair
mol_array = read_input(filename)

# Assign the input information as a class
mol_class = atom_list(mol_array)

# Convert the information of Cartesian coordninates and atom type into Coulomb matrix representation 
cm = cm_describer.cm_inter(mol_class.Natoms, mol_class.atomtype, mol_class.xyz)
#print(cm)

# Load the parameters of Kernel Ridge Regression
params = {"metric":'rbf', "gamma": 0.05}
weight_coef = np.loadtxt('Weight_List.txt')
trained_feature = np.loadtxt('Train_Feature.txt')

# Predict the value of electronic coupling by machine learning
cal_kernel = pairwise_kernels(cm[np.newaxis, :], trained_feature, **params)
V = np.dot(weight_coef, cal_kernel[0, :])
V = np.array(V).reshape(1)
print('The electronic coupling of the ethylene pair in %s is %.8f eV' %(filename, V))
np.savetxt('Prediction_V', V)

"""
