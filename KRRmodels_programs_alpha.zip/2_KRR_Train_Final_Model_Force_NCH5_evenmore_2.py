#coding:utf-8
from sklearn.kernel_ridge import KernelRidge
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import r2_score
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
from scipy.stats import gaussian_kde
import torch
from torch.autograd import Variable
import torch.utils.data as Data
import os
import time
import numpy as np
import pandas as pd
np.set_printoptions(threshold=10000000)
import random
import matplotlib
matplotlib.use('agg')  #agg backend is for writing to file, not for rendering in a window
import matplotlib.pyplot as plt

#################### Set System Parameters ####################
###### Set Feature File ######
Xfilename = '/work/kykuan/ML_dataset/datasets/Grace_NCH5_CM_evenmore_2'

###### Set Label File ######
Yfilename = '/work/kykuan/ML_dataset/datasets/Grace_NCH5_force_evenmore_2'	


###### Other Setting ######
Feature_Type = "XYZ_only"
total_sample = 95682
training_size = 55000
validation_size = 11000
figure_dpi=600
KRR_alpha=2.5e-9
KRR_gamma=2.5e-4
KRR_kernel='rbf'

random_seed = 42
torch.manual_seed(random_seed)    # reproducible

no_train = training_size
no_test = validation_size


#################### Subroutine: Suffle Samples ####################
def Suffle_Sample_XY(X,Y,batch_size):
    torch_dataset = Data.TensorDataset(X, Y)
    loader = Data.DataLoader(torch_dataset, batch_size, shuffle=True)
    
    for step, (X_batch, y_batch) in enumerate(loader):
        X = X_batch
        Y = y_batch
        return X,Y


#################### Loading Data ####################
###### Loading Data ######
if not os.path.exists(Xfilename):
  raise ValueError('%s does not exist, or the path is wrong!' % Xfilename)
if not os.path.exists(Yfilename):
  raise ValueError('%s does not exist, or the path is wrong!' % Yfilename)
X = pd.read_csv(Xfilename, sep='\s+',header=None)
Y = pd.read_csv(Yfilename, sep='\s+',header=None) 

X = X.loc[:(total_sample)]
#Y = Y.loc[:(total_sample-1)] # Check the label file and exculde the header column
Y = Y.loc[:(total_sample), 1:] # Check the label file and exculde the header column
Y = pd.DataFrame(Y)	
print(X.shape, Y.shape)


###### Suffle Samples ######
X_torch = Variable(torch.from_numpy(np.array(X)))
Y_torch = Variable(torch.from_numpy(np.array(Y)))
X_torch, Y_torch = Suffle_Sample_XY(X_torch, Y_torch, total_sample) # The original dataset is in the order of center-of-mass distance
X = X_torch.numpy()
Y = Y_torch.numpy()


###### Assign the Training Datasets & Testing Datasets ######
nv = training_size + validation_size
Train_CM, Train_EC = X[:training_size, :], Y[:training_size, :]
Test_CM, Test_EC = X[training_size:nv, :], Y[training_size:nv, :]
print(Train_CM.shape, Train_EC.shape)
print(Test_CM.shape, Test_EC.shape)



#################### Run Scikit-Learn ##################
kr = KernelRidge(alpha=KRR_alpha, gamma=KRR_gamma, kernel=KRR_kernel)



########## Training ##########
print('Training......')
stime = time.time()
X = np.array(Train_CM, dtype=float)
Y = np.array(Train_EC, dtype=float)
kr.fit(X,Y)


########## Save General Model Information ##########
cpu_time_min = (time.time() - stime)/60.0
Output_summary = open("ML_Model_Info.txt", 'w')
Output_summary.write('Descriptor: %s\n' %(Feature_Type))
Output_summary.write('Number of Training Dataset: %s\n' %(no_train))
Output_summary.write('Number of Testing Dataset: %s\n' %(no_test))
Output_summary.write('Cumputing Time: %.3f min \n' %(cpu_time_min))
Output_summary.write('-------------------------------------------------------- \n')
Output_summary.write('%s\n' %(kr.get_params))



#################### Save Weight Coefficients of Final Model  ####################
print("Dimension of the weights", kr.dual_coef_.shape) #####
np.savetxt('Weight_List.txt', kr.dual_coef_) #####
np.savetxt('Train_Feature.txt', X)
np.savetxt('Train_QC_Label.txt', Y)
np.savetxt('Test_Feature.txt', Test_CM)
np.savetxt('Test_QC_Label.txt', Test_EC)


print("Time for traing machine: %.3f" % (time.time() - stime))
print(kr.get_params)



#################### Estimate Performance: Testing Dataset ####################
########## Predicting & Evaluating ##########
Y_ex = Test_EC
cal_time = time.time()
Y_prd = kr.predict(Test_CM)
print("Calculation Time: %.10f  s" % (time.time() - cal_time))

np.savetxt("Test_Label.txt", Y_ex)
np.savetxt("Test_Predict.txt", Y_prd)

r_2 = kr.score(Test_CM,Y_ex)
MAE = mean_absolute_error(Y_ex,Y_prd)
MAE_kcalA = MAE*627.509/0.529
RMSE = np.power(mean_squared_error(Test_EC,Y_prd), 0.5)
RMSE_kcalA = RMSE*627.509/0.529

print("Error out of Sample")
print("r_2: %s" %(r_2))
print("MAE (kcal/mol): %s" %(MAE_kcalA))  #mean_absolute_error(y_true, y_pred)
print("RMSE (kcal/mol): %s" %(RMSE_kcalA))


# Report correlation, MAE, and RMSE for each axis of each atom
output_dim = Y_ex.shape[1]
MAE_list = []
RMSE_list = []
for i in range(output_dim):
    MAE = mean_absolute_error(np.reshape(Y_ex[:,i], (-1,1)),np.reshape(Y_prd[:,i], (-1, 1)))
    MAE_kcalA = MAE*627.509/0.529
    RMSE = np.power(mean_squared_error(np.reshape(Test_EC[:,i], (-1, 1)),np.reshape(Y_prd[:,i], (-1, 1))), 0.5)
    RMSE_kcalA = RMSE*627.509/0.529
    MAE_list.append(MAE_kcalA)
    RMSE_list.append(RMSE_kcalA)

print("MAE (kcal/molA) for individual axis | testing")    
print(np.reshape(MAE_list,(-1,3)))
print("")
print("RMSE for individual axis | testing")
print(np.reshape(RMSE_list,(-1,3)))
print("")



########## Save Predictive Labels ##########
Output_file = open("Test_Performance.txt", 'w')
Output_file.write('Number of Training Dataset: %s\n' %(no_train))
Output_file.write('Number of Testing Dataset: %s\n' %(no_test))
Output_file.write('r_2 for log scale: %s\n' %(r_2))
Output_file.write('MAE for log scale: %s\n' %(MAE))
Output_file.write('RMSE: %s\n' %(RMSE))
Output_file.write(' V_ex       V_pre \n')
for i in range(no_test):
    Output_file.write('%s    %s\n' %(Y_ex[i],Y_prd[i]))
Output_file.close()

########## Save Summary of Testing dataset ##########
Output_summary.write('-------------------------------------------------------- \n')
Output_summary.write('Error out of samples:\n')
Output_summary.write('r_2: %s\n' %(r_2))
Output_summary.write('MAE: %s\n' %(MAE))
Output_summary.write('RMSE: %s\n' %(RMSE))

"""
#### Pick one axis to plot ####
X = Y_ex[:, 5]
y = Y_prd[:, 5]
plt.scatter(X, y, alpha = 0.5)
m, b= np.polyfit(X, y, 1)
plt.plot(X, m*X+b, 'g-')
plt.title('Testing Performance at 2Z')
plt.xlabel('Expected force (Eh/bohr)')
plt.ylabel('Predicted force (Eh/Bohr)')
r2_ax = r2_score(X, y)
MAE_ax = mean_absolute_error(X, y)*627.509/0.529
RMSE_ax = np.power(mean_squared_error(X, y), 0.5)*627.509/0.529
plt.text(-0.1,0.1, "$R^2$: %2.5f\nMAE (kcal/molA): %2.3f\nRMSE (kcal/molA): %2.3f" %(r2_ax, MAE_ax, RMSE_ax), fontsize=8)
plt.savefig("test_axis2Z.png", dpi=figure_dpi,format="png")



# Make scatter plot of each axis of force
column_num = 10 # How many plot in a row?
output_dim = Y_ex.shape[1]
plot_column = output_dim // column_num
plot_rest = output_dim % column_num
add_col = 0

plt.figure()
if plot_rest > 0:
    add_col = 1
else:
    add_col = 0
plot_column = plot_column + add_col

plt.rc('xtick', labelsize=2)
plt.rc('ytick', labelsize=2)
fig, axs = plt.subplots(plot_column, column_num, clear=True)

for i in range(plot_column):
    for j in range(column_num):
        if column_num*i+j < output_dim:
            axs[i, j].scatter(Y_ex[:, column_num*i+j], Y_prd[:, column_num*i+j], s=1, alpha=0.01)
            
        else:
            break
#plt.title('Training Performance on Each Coordinate')
plt.savefig("Dipimethane_ScatterMatrix_Force_Test.png", dpi=figure_dpi,format="png")

# Make scatter plot for overall correlations
plt.figure()
plt.rc('xtick', labelsize=6)
plt.rc('ytick', labelsize=6)
plt.scatter(Y_ex, Y_prd, alpha=0.005)
plt.title('Testing Performance')
plt.xlabel('true relative energy (Eh/Bohr)')
plt.ylabel('predicted relative energy (Eh/Bohr)')
plt.text(30,80, "$R^2$: %2.5f\nMAE: %2.2f\nRMSE: %2.2f" %(r_2, MAE, RMSE), fontsize=12)
plt.savefig("Dipimethane_Scatter_Force_Test.png", dpi=figure_dpi,format="png")
"""



########## Estimate Performance: Training Dataset  ##########
########## Predicting & Evaluating ##########
Y_ex = Train_EC
Y_prd = kr.predict(Train_CM)

np.savetxt("Train_Label.txt", Y_ex)
np.savetxt("Train_Predict.txt", Y_prd)

r_2 = kr.score(Train_CM,Y_ex)
MAE = mean_absolute_error(Y_ex,Y_prd)
MAE_kcalA = MAE*627.509/0.529
RMSE = np.power(mean_squared_error(Train_EC,Y_prd), 0.5)
RMSE_kcalA = RMSE*627.509/0.529

print("Error out of Sample")
print("r_2: %s" %(r_2))
print("MAE (kcal/mol): %s" %(MAE_kcalA))  #mean_absolute_error(y_true, y_pred)
print("RMSE (kcal/mol): %s" %(RMSE_kcalA))


# Report correlation, MAE, and RMSE for each axis of each atom
output_dim = Y_ex.shape[1]
MAE_list = []
RMSE_list = []
for i in range(output_dim):
    MAE = mean_absolute_error(np.reshape(Y_ex[:,i], (-1,1)),np.reshape(Y_prd[:,i], (-1, 1)))
    MAE_kcalA = MAE*627.509/0.529
    RMSE = np.power(mean_squared_error(np.reshape(Train_EC[:,i], (-1, 1)),np.reshape(Y_prd[:,i], (-1, 1))), 0.5)
    RMSE_kcalA = RMSE*627.509/0.529
    MAE_list.append(MAE_kcalA)
    RMSE_list.append(RMSE_kcalA)

print("MAE (kcal/molA) for individual axis | training")
print(np.reshape(MAE_list,(-1,3)))
print("")
print("RMSE for individual axis | training")
print(np.reshape(RMSE_list,(-1,3)))
print("")


########## Save Predictive Labels ##########
Output_file = open("Train_Performance.txt", 'w')
Output_file.write('Number of Training Dataset: %s\n' %(no_train))
Output_file.write('Number of Testing Dataset: %s\n' %(no_train))
Output_file.write('r_2 for log scale: %s\n' %(r_2))
Output_file.write('MAE for log scale: %s\n' %(MAE))
Output_file.write('RMSE: %s\n' %(RMSE))
Output_file.write(' V_ex       V_pre \n')
for i in range(no_train):
    Output_file.write('%s    %s    \n' %(Y_ex[i],Y_prd[i]))
Output_file.close()

########## Save Summary of Training dataset ##########
Output_summary.write('-------------------------------------------------------- \n')
Output_summary.write('Error in samples:\n')
Output_summary.write('r_2: %s\n' %(r_2))
Output_summary.write('MAE: %s\n' %(MAE))
Output_summary.write('RMSE: %s\n' %(RMSE))
Output_summary.close()


"""
#### Plot Training Performance ####
# Make scatter plot on each output
output_dim = Y_ex.shape[1]
column_num = 10 # How many plot in a row?
plot_column = output_dim // column_num
plot_rest = output_dim % column_num
add_col = 0

plt.figure()
if plot_rest > 0:
    add_col = 1
else:
    add_col = 0
plot_column = plot_column + add_col

plt.rc('xtick', labelsize=2)
plt.rc('ytick', labelsize=2)

fig, axs = plt.subplots(plot_column, column_num, clear=True)


for i in range(plot_column):
    for j in range(column_num):
         if column_num*i+j < output_dim:
             axs[i, j].scatter(Y_ex[:, column_num*i+j], Y_prd[:, column_num*i+j], s=1, alpha=0.01)
         else:
             break
#plt.title('Training Performance on Each Coordinate')
plt.savefig("Dipimethane_ScatterMatrix_Force_Train.png", dpi=figure_dpi,format="png")


plt.figure()
plt.rc('xtick', labelsize=6)
plt.rc('ytick', labelsize=6)
plt.scatter(Y_ex, Y_prd, alpha=0.01)
plt.title('Training Performance')
plt.xlabel('true relative energy (kcal/mol)')
plt.ylabel('predicted relative energy (kcal/mol)')
plt.text(30,80, "$R^2$: %2.5f\nMAE: %2.2f\nRMSE: %2.2f" %(r_2, MAE, RMSE), fontsize=12)
plt.savefig("Dipimethane_Scatter_Force_Train.png", dpi=figure_dpi,format="png")
"""

print("Total Time: %.3f  min" % ((time.time() - stime)/60.0))

