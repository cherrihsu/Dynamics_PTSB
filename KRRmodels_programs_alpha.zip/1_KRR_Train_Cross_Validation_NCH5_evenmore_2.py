#coding:utf-8
from sklearn.kernel_ridge import KernelRidge
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import r2_score
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
from scipy.stats import gaussian_kde
import torch
from torch.autograd import Variable
import torch.utils.data as Data
import os
import time
import numpy as np
import pandas as pd
np.set_printoptions(threshold=10000000)
import random
import matplotlib
matplotlib.use('agg')  #agg backend is for writing to file, not for rendering in a window
import matplotlib.pyplot as plt

#################### Set System Parameters ####################
###### Set Feature File ######
Xfilename = '/Data1/kykuan/ML_dataset/datasets/Grace_NCH5_CM_evenmore_2'

###### Set Label File ######
Yfilename = '/Data1/kykuan/ML_dataset/datasets/Grace_NCH5_force_evenmore_2'	


###### Other Setting ######
Feature_Type = "CM_Summary_only_inter"
total_sample = 65000 #150000= 3~8A
training_size = 52000
validation_size = 13000
no_node=4
figure_dpi=600
tuned_parameters = {"alpha": [ 2.5e-9 ], 'gamma': [ 2.5e-4 ], "kernel": [ 'rbf' ]}

random_seed = 42
torch.manual_seed(random_seed)    # reproducible



no_train = training_size
no_test = validation_size


#################### Subroutine: Suffle Samples ####################
def Suffle_Sample_XY(X,Y,batch_size):
    torch_dataset = Data.TensorDataset(X, Y)
    loader = Data.DataLoader(torch_dataset, batch_size, shuffle=True)
    
    for step, (X_batch, y_batch) in enumerate(loader):
        X = X_batch
        Y = y_batch
        return X,Y


#################### Loading Data ####################
###### Loading Data ######
if not os.path.exists(Xfilename):
  raise ValueError('%s does not exist, or the path is wrong!' % Xfilename)
if not os.path.exists(Yfilename):
  raise ValueError('%s does not exist, or the path is wrong!' % Yfilename)
X = pd.read_csv(Xfilename, sep='\s+',header=None)
Y = pd.read_csv(Yfilename, sep='\s+',header=None) 

X = X.loc[:(total_sample)]
#Y = Y.loc[:(total_sample-1)] # Check the label file and exculde the header column
Y = Y.loc[:(total_sample), 1:] # Check the label file and exculde the header column
Y = pd.DataFrame(Y)	
print(X.shape, Y.shape)


###### Suffle Samples ######
X_torch = Variable(torch.from_numpy(np.array(X)))
Y_torch = Variable(torch.from_numpy(np.array(Y)))
X_torch, Y_torch = Suffle_Sample_XY(X_torch, Y_torch, total_sample) # The original dataset is in the order of center-of-mass distance
X = X_torch.numpy()
Y = Y_torch.numpy()


###### Assign the Training Datasets & Testing Datasets ######
nv = training_size + validation_size
Train_CM, Train_EC = X[:training_size, :], Y[:training_size]
Test_CM, Test_EC = X[training_size:nv, :], Y[training_size:nv]
print(Train_CM.shape, Train_EC.shape)
print(Test_CM.shape, Test_EC.shape)



#################### Run Scikit-Learn ##################
##### Fit KKR with parameter selection based on 5-fold cross validation #####
kr = GridSearchCV(KernelRidge(), cv=5, n_jobs=no_node, param_grid=tuned_parameters)




########## Training ##########
print('Training......')
stime = time.time()
X = np.array(Train_CM, dtype=float)
Y = np.array(Train_EC, dtype=float)
kr.fit(X,Y)


########## Save General Model Information ##########
cpu_time_min = (time.time() - stime)/60.0
Output_summary = open("ML_Model_Info_CV.txt", 'w')
Output_summary.write('Descriptor: %s\n' %(Feature_Type))
Output_summary.write('Number of Training Dataset: %s\n' %(no_train))
Output_summary.write('Number of Testing Dataset: %s\n' %(no_test))
Output_summary.write('Cumputing Time: %.3f min \n' % (cpu_time_min))
Output_summary.write('-------------------------------------------------------- \n')
Output_summary.write('%s\n' %(kr.get_params))


########## Save the Result of Hyper-parameter Optimization ##########
Output_summary.write('-------------------------------------------------------- \n')
Output_summary.write('Best Parameters: %s\n' %(kr.best_params_))
Output_summary.write('-------------------------------------------------------- \n')
Output_summary.write('CV Results:\n')
Output_summary.write('%s\n' %(kr.cv_results_))



print("Time for traing machine: %.3f" % (time.time() - stime))
print(kr.get_params)
print(kr.best_params_) #####



#################### Estimate Performance: Testing Dataset ####################
########## Predicting & Evaluating ##########
Y_ex = Test_EC
cal_time = time.time()
Y_prd = kr.predict(Test_CM)
print("Calculation Time: %.10f  s" % (time.time() - cal_time))

r_2 = kr.score(Test_CM,Y_ex)
MAE = mean_absolute_error(Y_ex,Y_prd)
MAE_kcal = MAE*627.509/0.529
RMSE = np.power(mean_squared_error(Test_EC,Y_prd), 0.5)
RMSE_kcal = RMSE*627.509/0.529
print("Error out of Sample")
print("r_2: %s" %(r_2))
print("MAE (kcal/mol-A): %s" %(MAE_kcal))  #mean_absolute_error(y_true, y_pred)
print("RMSE (kcal/mol-A): %s" %(RMSE_kcal))


########## Save Predictive Labels ##########
Output_file = open("Test_Performance_CV.txt", 'w')
Output_file.write('Number of Training Dataset: %s\n' %(no_train))
Output_file.write('Number of Testing Dataset: %s\n' %(no_test))
Output_file.write('r_2 for log scale: %s\n' %(r_2))
Output_file.write('MAE for log scale: %s\n' %(MAE))
Output_file.write('RMSE: %s\n' %(RMSE))
Output_file.write(' P_ex       P_pre \n')
for i in range(no_test):
    Output_file.write('%s    %s\n' %(Y_ex[i],Y_prd[i]))
Output_file.close()

########## Save Summary of Testing dataset ##########
Output_summary.write('-------------------------------------------------------- \n')
Output_summary.write('Error out of samples:\n')
Output_summary.write('r_2: %s\n' %(r_2))
Output_summary.write('MAE: %s\n' %(MAE))
Output_summary.write('RMSE: %s\n' %(RMSE))

#### Plot Testing Performance ####
plt.scatter(Y_ex, Y_prd)
plt.title('Testing Performance')
plt.xlabel('Expected forces (kcal/mol-A)')
plt.ylabel('Predicted forces (kcal/mol-A)')
plt.text(30,80, "$R^2$: %2.5f\nMAE: %2.2f\nRMSE: %2.2f" %(r_2, MAE, RMSE), fontsize=12)
plt.savefig("Nitrene_NCH5_force_testing.png", dpi=figure_dpi,format="png")



"""
########## Make Scatter Plot ##########
plt.figure(1, figsize=(9.5, 9), dpi=figure_dpi)
x = np.linspace(-1000,1000,100)
y = x
plt.plot(x, y, color="darkgrey", linewidth=1.0, linestyle="--")

#### Change Unit from eV to meV ####
Y_QC = Y_ex*1000
Y_ML = Y_prd*1000

#### Calculate the point density ###
x, y = Y_QC, Y_ML
xy = np.vstack([x,y])
z = gaussian_kde(xy)(xy)

#### Sort the points by density, so the densest points are plotted last ####
idx = z.argsort()
x, y, z = x[idx], y[idx], z[idx]
plt.scatter(x, y, c=z, s=25, cmap='jet')
#cb = plt.colorbar()
#cb.set_label('Gaussian Kernel Density', fontsize=30)

#plt.text(-530, 250, "$R^2$: %2.5f\nMAE: %2.2f\nRMSE: %2.2f" %(r_2, 1000*MAE, 1000*RMSE), fontsize=40) #Ethylene
plt.text(-430, 200, "$R^2$: %2.5f\nMAE: %2.2f\nRMSE: %2.2f" %(r_2, 1000*MAE, 1000*RMSE), fontsize=40) #Naphthalene


plt.xlabel('$\mathregular{V^{QC}}$ [meV]', fontsize=35)
plt.ylabel('$\mathregular{V^{ML}}$ [meV]', fontsize=35)
plt.xlim(-500, 500)  #Naphthalene
plt.ylim(-500, 500)  #Naphthalene
#plt.xlim(-600, 600) #Ethylene
#plt.ylim(-600, 600  #Ethylene
plt.tick_params(labelsize = 30)
#plt.grid(True)
plt.tight_layout()
plt.savefig("Scatter_Plot_Test_CV.png", dpi=figure_dpi,format="png")
"""



########## Estimate Performance: Training Dataset  ##########
########## Predicting & Evaluating ##########
Y_ex = Train_EC
Y_prd = kr.predict(Train_CM)

r_2 = kr.score(Train_CM,Y_ex)
MAE = mean_absolute_error(Y_ex,Y_prd)
MAE_kcal = MAE*627.509/0.529
RMSE = np.power(mean_squared_error(Train_EC,Y_prd), 0.5)
RMSE_kcal = RMSE*627.509/0.529
print("Error in Sample")
print("r_2: %s" %(r_2))
print("MAE (kcal/mol-A): %s" %(MAE_kcal))  #mean_absolute_error(y_true, y_pred)
print("RMSE (kcal/mol-A): %s" %(RMSE_kcal))

########## Save Predictive Labels ##########
Output_file = open("Train_Performance_CV.txt", 'w')
Output_file.write('Number of Training Dataset: %s\n' %(no_train))
Output_file.write('Number of Testing Dataset: %s\n' %(no_train))
Output_file.write('r_2 for log scale: %s\n' %(r_2))
Output_file.write('MAE for log scale: %s\n' %(MAE))
Output_file.write('RMSE: %s\n' %(RMSE))
Output_file.write(' PE_ex       PE_pre \n')
for i in range(no_train):
    Output_file.write('%s    %s    \n' %(Y_ex[i],Y_prd[i]))
Output_file.close()

########## Save Summary of Training dataset ##########
Output_summary.write('-------------------------------------------------------- \n')
Output_summary.write('Error in samples:\n')
Output_summary.write('r_2: %s\n' %(r_2))
Output_summary.write('MAE: %s\n' %(MAE))
Output_summary.write('RMSE: %s\n' %(RMSE))
Output_summary.close()

#### Plot Testing Performance ####
plt.scatter(Y_ex, Y_prd)
plt.title('Training Performance')
plt.xlabel('Expected forces (kcal/mol)')
plt.ylabel('Predicted forces (kcal/mol)')
plt.text(30,80, "$R^2$: %2.5f\nMAE: %2.2f\nRMSE: %2.2f" %(r_2, MAE, RMSE), fontsize=12)
plt.savefig("Nitrene_NCH5_training.png", dpi=figure_dpi,format="png")


"""
########## Make Scatter Plot ##########
plt.figure(2, figsize=(9.5, 9), dpi=figure_dpi)
x = np.linspace(-1000,1000,100)
y = x
plt.plot(x, y, color="darkgrey", linewidth=1.0, linestyle="--")

### Change Unit from eV to meV ###
Y_QC = Y_ex*1000
Y_ML = Y_prd*1000

#### Calculate the point density ###
x, y = Y_QC, Y_ML
xy = np.vstack([x,y])
z = gaussian_kde(xy)(xy)

#### Sort the points by density, so the densest points are plotted last ####
idx = z.argsort()
x, y, z = x[idx], y[idx], z[idx]
plt.scatter(x, y, c=z, s=25, cmap='jet')
#cb = plt.colorbar()
#cb.set_label('Gaussian Kernel Density', fontsize=30)

#plt.text(-530, 250, "$R^2$: %2.5f\nMAE: %2.2f\nRMSE: %2.2f" %(r_2, 1000*MAE, 1000*RMSE), fontsize=40) #Ethylene
plt.text(-430, 200, "$R^2$: %2.5f\nMAE: %2.2f\nRMSE: %2.2f" %(r_2, 1000*MAE, 1000*RMSE), fontsize=40) #Naphthalene


plt.xlabel('$\mathregular{V^{QC}}$ [meV]', fontsize=35)
plt.ylabel('$\mathregular{V^{ML}}$ [meV]', fontsize=35)
plt.xlim(-500, 500)  #Naphthalene
plt.ylim(-500, 500)  #Naphthalene
#plt.xlim(-600, 600) #Ethylene
#plt.ylim(-600, 600  #Ethylene
plt.tick_params(labelsize = 30)
#plt.grid(True)
plt.tight_layout()
plt.savefig("Scatter_Plot_Train_CV.png", dpi=figure_dpi,format="png")
"""


print("Total Time: %.3f  min" % ((time.time() - stime)/60.0))

